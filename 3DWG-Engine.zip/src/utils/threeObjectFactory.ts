import type { SceneObjectData } from '@/interfaces/sceneInterface.ts'
import type { GeometryData } from '@/types/geometry'
import type { HelperData } from '@/types/helper'
import type { MaterialData } from '@/types/material'
import {
  BoxGeometry,
  CapsuleGeometry,
  CircleGeometry,
  ConeGeometry,
  CylinderGeometry,
  DodecahedronGeometry,
  PerspectiveCamera,
  Group,
  IcosahedronGeometry,
  LineBasicMaterial,
  LineDashedMaterial,
  Mesh,
  MeshBasicMaterial,
  MeshLambertMaterial,
  MeshMatcapMaterial,
  MeshPhongMaterial,
  MeshPhysicalMaterial,
  MeshStandardMaterial,
  MeshToonMaterial,
  Object3D,
  OctahedronGeometry,
  PlaneGeometry,
  PointsMaterial,
  RingGeometry,
  ShadowMaterial,
  SpriteMaterial,
  SphereGeometry,
  TetrahedronGeometry,
  TorusGeometry,
  TorusKnotGeometry,
  Color,

  ArrowHelper,
  AxesHelper,
  Box3,
  Box3Helper,
  BoxHelper,
  CameraHelper,
  DirectionalLightHelper,
  GridHelper,
  HemisphereLightHelper,
  Plane,
  PlaneHelper,
  PointLightHelper,
  PolarGridHelper,
  SkeletonHelper,
  SpotLightHelper,
  Vector3
} from 'three/webgpu'

import { RectAreaLightHelper } from 'three/addons/helpers/RectAreaLightHelper.js'
import { LightProbeHelper } from 'three/addons/helpers/LightProbeHelper.js'
import { VertexNormalsHelper } from 'three/addons/helpers/VertexNormalsHelper.js'

/** Sync Three transform from SceneObjectData */
export function applyTransform(obj: Object3D, data: SceneObjectData) {
  const { position, rotation, scale } = data.transform
  obj.position.set(position[0], position[1], position[2])
  obj.rotation.set(rotation[0], rotation[1], rotation[2])
  obj.scale.set(scale[0], scale[1], scale[2])
}

/** Sync common render-state attributes from SceneObjectData to a Three Object3D */
export function syncThreeObjectState(obj: Object3D, data: SceneObjectData) {
  applyTransform(obj, data)
  obj.visible = data.visible ?? obj.visible
  ;(obj as any).castShadow = data.castShadow ?? (obj as any).castShadow
  ;(obj as any).receiveShadow = data.receiveShadow ?? (obj as any).receiveShadow
  obj.frustumCulled = data.frustumCulled ?? obj.frustumCulled
  obj.renderOrder = data.renderOrder ?? obj.renderOrder
  obj.name = data.name ?? obj.name
  obj.userData = { ...obj.userData, ...data.userData, sceneObjectId: data.id, sceneObjectType: data.type }
}

/** Create geometry from GeometryData (fallback: BoxGeometry) */
function createGeometryFromData(geo?: GeometryData) {
  if (!geo) return new BoxGeometry(1, 1, 1)

  switch (geo.type) {
    case 'box':
      return new BoxGeometry(
        geo.width ?? 1,
        geo.height ?? 1,
        geo.depth ?? 1,
        geo.widthSegments ?? 1,
        geo.heightSegments ?? 1,
        geo.depthSegments ?? 1
      )
    case 'sphere':
      return new SphereGeometry(
        geo.radius ?? 1,
        geo.widthSegments ?? 32,
        geo.heightSegments ?? 16,
        geo.phiStart ?? 0,
        geo.phiLength ?? Math.PI * 2,
        geo.thetaStart ?? 0,
        geo.thetaLength ?? Math.PI
      )
    case 'cylinder':
      return new CylinderGeometry(
        geo.radiusTop ?? 1,
        geo.radiusBottom ?? 1,
        geo.height ?? 2,
        geo.radialSegments ?? 32,
        geo.heightSegments ?? 1,
        geo.openEnded ?? false,
        geo.thetaStart ?? 0,
        geo.thetaLength ?? Math.PI * 2
      )
    case 'cone':
      return new ConeGeometry(
        geo.radius ?? 1,
        geo.height ?? 2,
        geo.radialSegments ?? 32,
        geo.heightSegments ?? 1,
        geo.openEnded ?? false,
        geo.thetaStart ?? 0,
        geo.thetaLength ?? Math.PI * 2
      )
    case 'plane':
      return new PlaneGeometry(geo.width ?? 1, geo.height ?? 1, geo.widthSegments ?? 1, geo.heightSegments ?? 1)
    case 'torus':
      return new TorusGeometry(
        geo.radius ?? 1,
        geo.tube ?? 0.4,
        geo.radialSegments ?? 8,
        geo.tubularSegments ?? 6,
        geo.arc ?? Math.PI * 2
      )
    case 'torusKnot':
      return new TorusKnotGeometry(
        geo.radius ?? 1,
        geo.tube ?? 0.4,
        geo.tubularSegments ?? 64,
        geo.radialSegments ?? 8,
        geo.p ?? 2,
        geo.q ?? 3
      )
    case 'tetrahedron':
      return new TetrahedronGeometry(geo.radius ?? 1, geo.detail ?? 0)
    case 'octahedron':
      return new OctahedronGeometry(geo.radius ?? 1, geo.detail ?? 0)
    case 'dodecahedron':
      return new DodecahedronGeometry(geo.radius ?? 1, geo.detail ?? 0)
    case 'icosahedron':
      return new IcosahedronGeometry(geo.radius ?? 1, geo.detail ?? 0)
    case 'circle':
      return new CircleGeometry(
        geo.radius ?? 1,
        geo.segments ?? 8,
        geo.thetaStart ?? 0,
        geo.thetaLength ?? Math.PI * 2
      )
    case 'ring':
      return new RingGeometry(
        geo.innerRadius ?? 0.5,
        geo.outerRadius ?? 1,
        geo.thetaSegments ?? 8,
        geo.phiSegments ?? 1,
        geo.thetaStart ?? 0,
        geo.thetaLength ?? Math.PI * 2
      )
    case 'capsule':
      return new CapsuleGeometry(
        geo.radius ?? 1,
        geo.length ?? 1,
        geo.capSegments ?? 4,
        geo.radialSegments ?? 8
      )
    default:
      return new BoxGeometry(1, 1, 1)
  }
}

/** Create material from MaterialData (fallback: MeshStandardMaterial) */
function createMaterialFromData(mat?: MaterialData) {
  if (!mat) return new MeshStandardMaterial({ color: 0xcccccc })

  const baseColor = mat?.color ? new Color(mat.color) : new Color('#cccccc')

  switch (mat.type) {
    case 'basic':
      return new MeshBasicMaterial({ color: baseColor })
    case 'lambert':
      return new MeshLambertMaterial({ color: baseColor })
    case 'phong':
      return new MeshPhongMaterial({
        color: baseColor,
        specular: new Color(mat.specular ?? '#111111'),
        shininess: mat.shininess ?? 30
      })
    case 'standard':
      return new MeshStandardMaterial({
        color: baseColor,
        roughness: mat.roughness ?? 1,
        metalness: mat.metalness ?? 0
      })
    case 'physical':
      return new MeshPhysicalMaterial({
        color: baseColor,
        roughness: mat.roughness ?? 1,
        metalness: mat.metalness ?? 0,
        clearcoat: mat.clearcoat ?? 0,
        clearcoatRoughness: mat.clearcoatRoughness ?? 0,
        ior: mat.ior ?? 1.5,
        transmission: mat.transmission ?? 0,
        thickness: mat.thickness ?? 0.01
      })
    case 'toon':
      return new MeshToonMaterial({ color: baseColor })
    case 'matcap':
      return new MeshMatcapMaterial({ color: baseColor })
    case 'lineBasic':
      return new LineBasicMaterial({ color: baseColor, linewidth: mat.linewidth ?? 1 })
    case 'lineDashed':
      return new LineDashedMaterial({
        color: baseColor,
        linewidth: mat.linewidth ?? 1,
        dashSize: mat.dashSize ?? 3,
        gapSize: mat.gapSize ?? 1,
        scale: mat.scale ?? 1
      })
    case 'points':
      return new PointsMaterial({ color: baseColor, size: mat.size ?? 1, sizeAttenuation: mat.sizeAttenuation ?? true })
    case 'sprite':
      return new SpriteMaterial({ color: baseColor })
    case 'shadow':
      return new ShadowMaterial({ opacity: mat.opacity ?? 1 })
    default:
      return new MeshStandardMaterial({ color: baseColor })
  }
}

/** Create helper-style Object3D instances from HelperData */
function createHelperFromData(helper?: HelperData, objectsMap?: Map<string, Object3D>) {
  if (!helper) return new AxesHelper(1)

  const target = helper && 'targetId' in helper && helper.targetId ? objectsMap?.get(helper.targetId) : undefined

  switch (helper.type) {
    case 'axes':
      return new AxesHelper(helper.size ?? 1)
    case 'grid':
      return new GridHelper(
        helper.size ?? 10,
        helper.divisions ?? 10,
        helper.colorCenterLine ?? '#444444',
        helper.colorGrid ?? '#888888'
      )
    case 'polarGrid':
      return new PolarGridHelper(
        helper.radius ?? 5,
        helper.radials ?? 16,
        helper.circles ?? 8,
        helper.divisions ?? 64,
        helper.color1 ?? '#444444',
        helper.color2 ?? '#888888'
      )
    case 'arrow': {
      const dir = helper.dir ?? [0, 1, 0]
      const origin = helper.origin ?? [0, 0, 0]
      const dirVec = new Vector3(dir[0], dir[1], dir[2]).normalize()
      const originVec = new Vector3(origin[0], origin[1], origin[2])
      return new ArrowHelper(
        dirVec,
        originVec,
        helper.length ?? 1,
        helper.color ?? '#ffffff',
        helper.headLength,
        helper.headWidth
      )
    }
    case 'box':
      return target ? new BoxHelper(target, helper.color) : new AxesHelper(1)
    case 'box3': {
      const min = helper.min ?? [0, 0, 0]
      const max = helper.max ?? [1, 1, 1]
      return new Box3Helper(new Box3(new Vector3(min[0], min[1], min[2]), new Vector3(max[0], max[1], max[2])), helper.color)
    }
    case 'camera':
      return target ? new CameraHelper(target as any) : new AxesHelper(1)
    case 'directionalLight':
      return target ? new DirectionalLightHelper(target as any, helper.size, helper.color) : new AxesHelper(1)
    case 'hemisphereLight':
      return target ? new HemisphereLightHelper(target as any, helper.size ?? 1, helper.color) : new AxesHelper(1)
    case 'pointLight':
      return target ? new PointLightHelper(target as any, helper.sphereSize, helper.color) : new AxesHelper(1)
    case 'spotLight':
      return target ? new SpotLightHelper(target as any, helper.color) : new AxesHelper(1)
    case 'rectAreaLight':
      return target ? new RectAreaLightHelper(target as any, helper.color) : new AxesHelper(1)
    case 'plane': {
      const normal = helper.normal ?? [0, 1, 0]
      const plane = new Plane(new Vector3(normal[0], normal[1], normal[2]).normalize(), helper.constant ?? 0)
      return new PlaneHelper(plane, helper.size ?? 1, new Color(helper.color ?? '#444444').getHex())
    }
    case 'skeleton':
      return target ? new SkeletonHelper(target as any) : new AxesHelper(1)
    case 'lightProbe':
      return target ? new LightProbeHelper(target as any, helper.size ?? 1) : new AxesHelper(1)
    case 'vertexNormals':
      return target ? new VertexNormalsHelper(target as any, helper.size ?? 1, new Color(helper.color ?? '#444444').getHex()) : new AxesHelper(1)
    default:
      return new AxesHelper(1)
  }
}

/** Create Three Object3D from SceneObjectData (geometry, material, helper, name) */
export function createThreeObject(data: SceneObjectData, opts?: { objectsMap?: Map<string, Object3D> }): Object3D {
  let obj: Object3D
  switch (data.type) {
    case 'group':
    case 'model':
      obj = new Group()
      break
    case 'mesh':
      obj = new Mesh(
        createGeometryFromData(data.mesh?.geometry),
        createMaterialFromData(data.mesh?.material)
      )
      break
    case 'camera': {
      const cameraOpts = (data as any).cameraOptions as {
        fov?: number
        near?: number
        far?: number
      } | undefined
      obj = new PerspectiveCamera(
        cameraOpts?.fov ?? 50,
        1,
        cameraOpts?.near ?? 0.01,
        cameraOpts?.far ?? 2000
      )
      break
    }
    case 'helper':
      obj = createHelperFromData(data.helper, opts?.objectsMap)
      break
    default:
      obj = new Object3D()
  }
  obj.name = data.name ?? data.id
  obj.userData.sceneObjectId = data.id
  obj.userData.sceneObjectType = data.type
  applyTransform(obj, data)
  return obj
}
