import type { SceneObjectData } from '@/interfaces/sceneInterface.ts'

export interface SceneObjectInput {
  id?: string
  type: SceneObjectData['type']
  name?: string
  parentId?: string
  mesh?: SceneObjectData['mesh']
  helper?: SceneObjectData['helper']
  transform?: Partial<SceneObjectData['transform']>
  visible?: SceneObjectData['visible']
  castShadow?: SceneObjectData['castShadow']
  receiveShadow?: SceneObjectData['receiveShadow']
  frustumCulled?: SceneObjectData['frustumCulled']
  renderOrder?: SceneObjectData['renderOrder']
  childrenIds?: SceneObjectData['childrenIds']
  userData?: SceneObjectData['userData']
}

export function createSceneObjectData(input: SceneObjectInput): SceneObjectData {
  return {
    id: input.id ?? '',
    type: input.type,
    name: input.name,
    parentId: input.parentId,
    mesh: input.mesh,
    helper: input.helper,
    transform: {
      position: input.transform?.position ?? [0, 0, 0],
      rotation: input.transform?.rotation ?? [0, 0, 0],
      scale: input.transform?.scale ?? [1, 1, 1]
    },
    visible: input.visible ?? true,
    castShadow: input.castShadow ?? false,
    receiveShadow: input.receiveShadow ?? false,
    frustumCulled: input.frustumCulled ?? false,
    renderOrder: input.renderOrder ?? 0,
    childrenIds: input.childrenIds ?? [],
    userData: input.userData ?? {}
  }
}

