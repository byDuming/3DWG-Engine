<script setup lang="ts">
  import { ref,computed } from 'vue'
  import { useSceneStore } from '@/stores/modules/useScene.store'
  const sceneStore = useSceneStore()

  function handleChange() {
    console.log('change')
  }

  
  type TransformKey = 'position' | 'rotation' | 'scale'

  function updateTransform(key: TransformKey, axis: 0 | 1 | 2, value: number | null) {
    const id = sceneStore.selectedObjectId
    if (!id) return
    const current = sceneStore.cureentObjectData?.transform[key] ?? [0, 0, 0]
    const next = [...current] as [number, number, number]
    next[axis] = Number(value ?? 0)
    sceneStore.updateSceneObjectData(id, { transform: { [key]: next } } as any)
  }

  function handleBlurChangePosition(value: number) {
    console.log('blur',value)
    sceneStore.updateSceneObjectData(sceneStore.selectedObjectId!, {
      transform: {
        position: [
          Number((document.querySelectorAll('input.n-input-number__input')[0] as HTMLInputElement).value),
          Number((document.querySelectorAll('input.n-input-number__input')[1] as HTMLInputElement).value),
          Number((document.querySelectorAll('input.n-input-number__input')[2] as HTMLInputElement).value)
        ],
        rotation: sceneStore.cureentObjectData?.transform.rotation!,
        scale: sceneStore.cureentObjectData?.transform.scale!
      }
    })
  }

  function updateVisible(visible: boolean) {
    const id = sceneStore.selectedObjectId
    if (!id) return
    sceneStore.updateSceneObjectData(id, { visible } as any)
  }
</script>

<template>
  <span>属性面板</span>
  <br/>
  选择的对象ID: {{ sceneStore.selectedObjectId }}
  <br/>
  <n-flex class="n-flex" vertical>
    <n-grid x-gap="12" :cols="8">
      <n-gi class="gid-item" :span="2">
        类型
      </n-gi>
      <n-gi class="gid-item" :span="6">
        <n-input :value="sceneStore.cureentObjectData?.type" type="text" disabled />
      </n-gi>
    </n-grid>

    
    <br/>
    <!-- 位置 -->
    <n-grid x-gap="6" :cols="11">
      <n-gi class="gid-item" :span="2">
        位置
      </n-gi>
      <n-gi class="gid-item" :span="3">
          <n-input-number
            :value="sceneStore.cureentObjectData?.transform.position[0]"
            @update:value="(v:number) => updateTransform('position', 0, v)"
            :show-button="false"
          />
      </n-gi>
      <n-gi class="gid-item" :span="3">
          <n-input-number
            :value="sceneStore.cureentObjectData?.transform.position[1]"
            @update:value="(v:number) => updateTransform('position', 1, v)"
            :show-button="false"
          />
      </n-gi>
      <n-gi class="gid-item" :span="3">
          <n-input-number
            :value="sceneStore.cureentObjectData?.transform.position[2]"
            @update:value="(v:number) => updateTransform('position', 2, v)"
            :show-button="false"
          />
      </n-gi>
    </n-grid>

    <br/>
    <!-- 旋转 -->
    <n-grid x-gap="6" :cols="11">
      <n-gi class="gid-item" :span="2">
        旋转
      </n-gi>
      <n-gi class="gid-item" :span="3">
          <n-input-number
            :value="sceneStore.cureentObjectData?.transform.rotation[0]"
            @update:value="(v:number) => updateTransform('rotation', 0, v)"
            :show-button="false"
          />
      </n-gi>
      <n-gi class="gid-item" :span="3">
          <n-input-number
            :value="sceneStore.cureentObjectData?.transform.rotation[1]"
            @update:value="(v:number) => updateTransform('rotation', 1, v)"
            :show-button="false"
          />
      </n-gi>
      <n-gi class="gid-item" :span="3">
          <n-input-number
            :value="sceneStore.cureentObjectData?.transform.rotation[2]"
            @update:value="(v:number) => updateTransform('rotation', 2, v)"
            :show-button="false"
          />
      </n-gi>
    </n-grid>

    <br/>
    <!-- 缩放 -->
    <n-grid x-gap="6" :cols="11">
      <n-gi class="gid-item" :span="2">
        缩放
      </n-gi>
      <n-gi class="gid-item" :span="3">
        <n-input-number
          :value="sceneStore.cureentObjectData?.transform.scale[0]"
          @update:value="(v:number) => updateTransform('scale', 0, v)"
          :show-button="false"
        >
        <template #suffix>
          °
        </template>
      </n-input-number>
      </n-gi>
      <n-gi class="gid-item" :span="3">
        <n-input-number
          :value="sceneStore.cureentObjectData?.transform.scale[1]"
          @update:value="(v:number) => updateTransform('scale', 1, v)"
          :show-button="false"
        >
          <template #suffix>
            °
          </template>
        </n-input-number>
      </n-gi>
      <n-gi class="gid-item" :span="3">
        <n-input-number
          :value="sceneStore.cureentObjectData?.transform.scale[2]"
          @update:value="(v:number) => updateTransform('scale', 2, v)"
          :show-button="false"
        >
          <template #suffix>
            °
          </template>
        </n-input-number>
      </n-gi>
    </n-grid>

    <br/>
    <!-- 可见性 -->
    <n-grid x-gap="6" :cols="8">
      <n-gi class="gid-item" :span="2">
        可见性
      </n-gi>
      <n-gi class="gid-item" :span="6">
        <n-switch
          :value="sceneStore.cureentObjectData?.visible"
          @update:value="(v:boolean) => updateVisible(v)"
        />
      </n-gi>
    </n-grid>

  </n-flex>
</template>

<style scoped>
  
  .gid-item {
    margin-block: auto;
    font-weight: bold;
    margin-right: 0.3vw;
  }
</style>
